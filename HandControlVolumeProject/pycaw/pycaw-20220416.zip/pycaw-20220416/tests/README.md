# Tests

## Run all tests

Using Python unit testing framework:
```bat
pytest tests
```

Using Tox:
```bat
tox
```
